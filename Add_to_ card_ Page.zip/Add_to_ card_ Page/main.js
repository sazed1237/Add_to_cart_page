
const ITEMS = [
    {
        id: 1,
        name: 'WearLess Mouse',
        price: 1200,
        image: './images/1-300x300.jpeg',
        qty: 1
    },
    {
        id: 2,
        name: 'Keyboard Mouse & Headphone',
        price: 2200,
        image: './images/1892604_0_original.jpg',
        qty: 1
    },
    {
        id: 3,
        name: 'Keyboard, Mouse & Spekers',
        price: 1300,
        image: './images/75c070c74cb64647b3a0e61826ba609a-Computer-Accessories.jpg',
        qty: 1
    },
    {
        id: 4,
        name: 'Sporsts Bike',
        price: 500000,
        image: './images/bike.jpg',
        qty: 1
    },
    {
        id: 5,
        name: 'Sports cycle',
        price: 25000,
        image: './images/cycle.jpg',
        qty: 1
    },
];

var cartDataString = JSON.stringify(ITEMS);



const openBtn = document.getElementById('open_cart_btn');
const cart = document.getElementById('sidecart')
const closeBtn = document.getElementById('close_btn')
const backdrop = document.querySelector('.backdrop')
const itemsEl = document.querySelector('.items')
const cartItems = document.querySelector('.cart_items')
const itemsNum = document.getElementById('items_num')
const subtotalPrice = document.getElementById('subtotal_price')



let cart_data = []


openBtn.addEventListener('click', openCart)
closeBtn.addEventListener('click', closeCart)
backdrop.addEventListener('click', closeCart)

randerItems()
randerCartItems()


// open cart
function openCart() {
    cart.classList.add('open')
    backdrop.style.display = 'block'

     // Store the cart_data in Localstorage
     localStorage.setItem("cart_data", JSON.stringify(cart_data));

    
    setTimeout(() => {
        backdrop.classList.add('show')
    }, 0);
}
// close cart
function closeCart() {
    cart.classList.remove('open')
    backdrop.classList.remove('show')
    
    setTimeout(() => {
        backdrop.style.display = 'none'        
    }, 500);
}


// add items to cart
function addItem(idx, itemId) {
    // find same items
    const foundedItem = cart_data.find(
        item => item.id.toString() === itemId.toString()
        )

        if(foundedItem) {
            increaseQty(itemId)
        } else {
            cart_data.push(ITEMS[idx])
        }

        // Store the updated cart_data in Localstorage
        localStorage.setItem("cart_data", JSON.stringify(cart_data));


    updateCart()
    openCart()

}

// Store the Data in Localstorage 
// localStorage.setItem("cart_data", cartDataString);

// Retrieve cart data from Localstorage
var storedCartDataString = localStorage.getItem("cart_data");
var storedCartData = JSON.parse(storedCartDataString);

// Check if stored cart data exists and is valid
if (storedCartData) {
    cart_data = storedCartData;
}

updateCart()

// remove cart Items
function removeCartItem(itemId) {
    cart_data = cart_data.filter(item => item.id != itemId)

    // Update the cart data in Localstorage
    localStorage.setItem("cart_data", JSON.stringify(cart_data));


    updateCart()
}

// increase qty
function increaseQty(itemId) {
    cart_data = cart_data.map((item) => 
        item.id.toString() === itemId.toString()
        ? { ...item, qty: item.qty + 1 }
        : item
    )

    updateCart()
}
// Descrease qty
function descreaseQty(itemId) {
    cart_data = cart_data.map((item) => 
        item.id.toString() === itemId.toString()
        ? { ...item, qty: item.qty > 1 ? item.qty - 1 : item.qty }
        : item
    )

    updateCart()
}


// calculate items number
function calculateItemsNum() {
    let itemsCount = 0

    cart_data.forEach((item) => (itemsCount += item.qty))

    itemsNum.innerText = itemsCount

}

// calculate subtotal price
function calculateSubtotalPrice() {
    let subtotal = 0

    cart_data.forEach((item) => (subtotal += item.price * item.qty))

    subtotalPrice.innerText = subtotal


}



// Rander items
function randerItems() {
    ITEMS.forEach((item, idx) => {
        const itemEl = document.createElement('div')
        itemEl.classList.add('item')
        itemEl.onclick = () => addItem(idx, item.id)
        itemEl.innerHTML = `
            <img src="${item.image}" alt="">
            <button id="add-to-cart">Add to Cart</button>
        `
        itemsEl.appendChild(itemEl)
    })
}



// Display / Rander cart Items
function randerCartItems() {
    // remove Everything from cart
    cartItems.innerHTML = ''
    // add new data
    cart_data.forEach(item => {
        const cartItem = document.createElement('div')
        cartItem.classList.add('cart_item')
        cartItem.innerHTML = `
        <div class="remove_item" onclick= "removeCartItem(${item.id})">
        <span>&times;</span>
    </div>
    <div class="item_img">
        <img src="${item.image}" alt="">
    </div>
    <div class="item-details">
        <p>${item.name}</p>
        <strong>$${item.price}</strong>
        <div class="qty">
            <span onclick="descreaseQty(${item.id})">-</span>
            <strong>${item.qty}</strong>
            <span onclick="increaseQty(${item.id})" >+</span>
        </div>
    </div>
        `
        cartItems.appendChild(cartItem)
    })
}


function updateCart() {
    // rander cart items with updated data
    randerCartItems()
    // update items number in cart
    calculateItemsNum()

    // update subtotal price
    calculateSubtotalPrice()


}

updateCart()








// // show Massage 
// document.getElementById("add-to-cart").addEventListener("click", function() {
//     showNotification("You've successfully added this item to your cart.");
//   });
  
//   function showNotification(message) {
//     // Create a notification element
//     var notification = document.createElement("div");
//     notification.className = "notification";
//     notification.innerText = message;
  
//     // Append the notification to the body
//     document.body.appendChild(notification);
  
//     // Automatically remove the notification after a few seconds
//     setTimeout(function() {
//       notification.remove();
//     }, 3000);
//   }
  